-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: ai
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `mb_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '회원 아이디',
  `mb_name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '회원 이름',
  `mb_pwd` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '회원 비밀번호',
  `mb_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '회원 이메일',
  `admin_yn` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '관리자 여부',
  `mb_mbti` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '회원 MBTI',
  `idx` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='회원 정보';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES ('aa','aa','aa','a@a','n','djka',1),('asd','asd','asd','asd@naver.com','Y','dfsafsad',2),('asdf','asdf','asdf','asdf@asdf','y','istj',3),('j','j','j','j@j','n','nnjhn',4),('k','k','k','k@k','y','asdj',5),('qwer','aaasdf','qwer','a@a','n','dfga',6),('gksekgml1','gksekgml','123','123@naver.com','남','ISFP',7),('gksekgml123','gksekgml2','123','gksekgml@naver.com','남','ESTP',8),('gksekgml123','123','123','gksekgml@naver.com','남','ESTP',9),('gksekgml123456','dfdfdf','123','gksekgml@naver.com','남','ESTP',10),('rlaghdaud','김홍명','123','rlaghdaud@rlaghdaud.com','남','ESTP',11),('qkrruddnjs','박경원','1234','123@123','남','ESTP',12),('qkrruddnjs12','qkrruddnjs','KOKO90','123@123','남','ENFJ',13),('rlaghdaud123','김홍명','123','123@123','남','INTJ',14),('rlaghdaud1234','123','123','123@123','남','INTJ',15),('rlaghdaud12345','123','123','email@email','남','INTJ',16),('dgdg','123','12345','123@123','남','INTJ',17),('qkrruddnjs1234','123','123','123@anve','남','INTJ',18),('qkrruddnjs1234','123','123','123@anve','남','INTJ',19),('qkrruddnjs1234','123','123','123@anve','남','INTJ',20),('qkrruddnjs1234','123','123','123@anve','남','INTJ',21),('qkrruddnjs123124','123','123','123@213','남','INTJ',22),('qkrruddnjs123452','123','123','anver@df','남','INTJ',23),('qkrruddnjs123452','123','123','anver@df','남','INTJ',24),('rlarud','123','123','123@123','남','INTJ',25),('rlarud','123','123','123@123','남','INTJ',26),('yoho90','김지현','koko90','yoho90@naver.com','여','ISTJ',27),('qkrruddnjs12314','123','123','123@123','남','INTJ',29),('qkrruddnjs1231231','123','123','123@123','남','ISTJ',35),('asdfasdf','asdf','asdf','asdf@asdf','남','ESTJ',36),('bipop43','김지현','wlgus1004','bipop43@gmail.com','여자','ENFP',37),('bipop44','aaa','koko90','aaa@aaa','남','ISTP',38);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-15 16:30:54
